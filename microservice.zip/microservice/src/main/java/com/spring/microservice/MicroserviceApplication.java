package com.spring.microservice;

import com.spring.microservice.model.Product;
import com.spring.microservice.service.ProductService;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class MicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceApplication.class, args);
	}

	@Bean
	CommandLineRunner run(ProductService productService) {
		return args -> {
			Product honey = new Product("Honey");
			productService.createProduct(honey);
		};
	}
}
