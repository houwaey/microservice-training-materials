package com.spring.microservice.controller;

import com.spring.microservice.exception.ProductNotFoundException;
import com.spring.microservice.model.Product;
import com.spring.microservice.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Collection;

@RestController
public class ProductController {

    /*
    * GET: find all - /product
    * GET: find by id - /product/id/{id} --> /product/id/1
    * GET: find by name - /product/name/{name} --> /product/name/paulo
    * POST: create + body - /product
    * PUT: update + body - /product/id/{id}
    * DELETE: delete - /product/id/{id}
    * */

    @Autowired
    private ProductService productService;

    @GetMapping("/product")
    public ResponseEntity<Object> getAllProducts() throws ProductNotFoundException {
        return new ResponseEntity<>(productService.getAllProducts(), HttpStatus.OK);
    }

    @GetMapping("/product/id/{productId}")
    public ResponseEntity<Object> getProductById(@PathVariable int productId) throws ProductNotFoundException {
        return new ResponseEntity<>(productService.getProductById(productId), HttpStatus.OK);
    }

    @GetMapping("/product/name/{productName}")
    public ResponseEntity<Object> getProductByName(@PathVariable String productName) {
        return null;
    }

    @PostMapping("/product")
    public ResponseEntity<Object> createProduct(@RequestBody @Valid Product product) {
        return new ResponseEntity<>(productService.createProduct(product), HttpStatus.OK);
    }

    @PutMapping("/product/id/{productId}")
    public ResponseEntity<Object> updateProduct(@PathVariable int productId, @RequestBody Product product) throws ProductNotFoundException {
        productService.updateProduct(productId, product);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @DeleteMapping("/product/id/{productId}")
    public ResponseEntity<Object> deleteProduct(@PathVariable int productId) throws ProductNotFoundException {
        productService.deleteProduct(productId);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
