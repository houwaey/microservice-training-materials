package com.spring.microservice.service;

import com.spring.microservice.exception.ProductNotFoundException;
import com.spring.microservice.model.Product;

import java.util.Collection;

public interface ProductService {
    Collection<Product> getAllProducts() throws ProductNotFoundException;
    Product getProductById(int productId) throws ProductNotFoundException;
    Product createProduct(Product product);
    void updateProduct(int productId, Product product) throws ProductNotFoundException;
    void deleteProduct(int productId) throws ProductNotFoundException;
}
