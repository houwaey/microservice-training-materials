package com.spring.microservice.service;

import com.spring.microservice.exception.ProductNotFoundException;
import com.spring.microservice.model.Product;
import com.spring.microservice.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Collection;

@Transactional
@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public Collection<Product> getAllProducts() throws ProductNotFoundException {
        Collection<Product> products = productRepository.findAll();
        if (products.isEmpty()) {
            throw new ProductNotFoundException("Product not found!");
        }
        return products;
    }

    @Override
    public Product getProductById(int productId) throws ProductNotFoundException {
        return productRepository.findById(productId)
                .orElseThrow(() -> new ProductNotFoundException("Product not found!"));
    }

    @Override
    public Product createProduct(Product product) {
        return productRepository.save(product);
    }

    @Override
    public void updateProduct(int productId, Product product) throws ProductNotFoundException {
        Product currentProduct = getProductById(productId);
        currentProduct.setName(product.getName());
    }

    @Override
    public void deleteProduct(int productId) throws ProductNotFoundException {
        Product product = getProductById(productId);
        productRepository.delete(product);
    }
}
