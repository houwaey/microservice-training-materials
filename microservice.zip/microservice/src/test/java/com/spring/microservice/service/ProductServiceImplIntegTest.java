package com.spring.microservice.service;

import com.spring.microservice.exception.ProductNotFoundException;
import com.spring.microservice.model.Product;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Collection;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ProductServiceImplIntegTest {

    @Autowired
    private ProductService productService;

    @Test
    void getAllProducts() throws ProductNotFoundException {
        Collection<Product> products = productService.getAllProducts();
        assertFalse(products.isEmpty());
    }

    @Test
    void getProductById() throws ProductNotFoundException {
        Product product = productService.getProductById(1);
        assertNotNull(product);
    }

    @Test
    void createProduct() {
        Product product = productService.createProduct(new Product("Almond"));
        assertNotNull(product);
    }

    @Test
    void updateProduct() throws ProductNotFoundException {
        productService.updateProduct(1, new Product("Banana"));
        Product product = productService.getProductById(1);
        assertEquals(product.getName(), "Banana");
    }

    @Test
    void deleteProduct() throws ProductNotFoundException {
        productService.deleteProduct(1);
        assertThrows(ProductNotFoundException.class, () -> productService.getProductById(1));
    }
}