package com.spring.microservice.service;

import com.spring.microservice.exception.ProductNotFoundException;
import com.spring.microservice.model.Product;
import com.spring.microservice.repository.ProductRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductServiceImplTest {

    @InjectMocks
    private ProductServiceImpl productService;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private Product product;

    @Test
    void getAllProducts() {
        when(productRepository.findAll()).thenReturn(new ArrayList<>());
        assertThrows(ProductNotFoundException.class, () -> productService.getAllProducts());
    }

    @Test
    void getProductById() throws ProductNotFoundException {
        when(productRepository.findById(anyInt())).thenReturn(Optional.of(product));
        Product product = productService.getProductById(1);
        assertNotNull(product);
    }

    @Test
    void createProduct() {
        when(productRepository.save(any(Product.class))).thenReturn(product);
        Product product = productService.createProduct(new Product("Banana"));
        assertNotNull(product);
    }

    @Test
    void updateProduct() {
    }

    @Test
    void deleteProduct() {
    }
}